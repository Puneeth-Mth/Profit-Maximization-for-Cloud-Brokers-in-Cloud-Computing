/*
*Author : Omar Adnan Isaid for the Master Security Course with Dr Hisham Abusaimeh
*201315023
*RCF4 is stream cipher  divided the message into 256-bits block , and XoR the block with the 
*RCF4 generated Key for each block for encryption and Xor again for decryption
 */
package RC4MainPackage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class RC4 {

    // S & T vectors
    protected int[] S;
    protected byte[] T_signedByteKey = new byte[MessageBlockSize];
    protected int[] RC4Key;
    protected byte[] Message;
    protected byte[] CipherMessage;
    protected byte[] MesssageBlock;
    protected byte[] CipherBlock;
    // input key in signed key format
    protected byte[] signedByteKey;
    protected byte plainText[];
    // Num of bytes in the message
    int MessageBytesNum;
    int paddingNumber = 10;
    // where to write the exception stack        
    PrintStream ps = new PrintStream(System.out);
    public static final int MessageBlockSize = 256;
    // Name of files
    // input file contains original message
    String strInputFile = "/omar/Text.txt";
    // file where to save ciphered text
    String strOutputFile = "/omar/output.txt";
    // file contains the key
    String strkeyFile = "/omar/Key.txt";
    // initialization of S and T (T_signedBytekey) vectors
    public void initialization() {
        try {
            // initilization of vector S from 0 to 255
            S = new int[MessageBlockSize];
            int index = 0;
            for (; index < MessageBlockSize; index++) {
                S[index] = (index);
            }
            // Read the input key and set to the T vector 
            // The T vector is T_signedByteKey 
            int keyIndex = 0;
            index = 0;
            for (; index < MessageBlockSize; index++) {
                if (keyIndex == signedByteKey.length) {
                    keyIndex = 0;
                }
                T_signedByteKey[index] = signedByteKey[keyIndex];
                keyIndex++;
            }
            // 1st permutation of S vector elements
            // pointers for permutation the elements of S vector 
            int Ptr1 = 0;
            int Ptr2 = 0;
            int temp;
            int intUnSignedByteKey;
            for (; Ptr1 < MessageBlockSize; Ptr1++) {
                intUnSignedByteKey = getUnsigendByte(T_signedByteKey[Ptr1]);
                Ptr2 = (Ptr2 + S[Ptr1] + intUnSignedByteKey) % MessageBlockSize;
                // use the pointers to swap two elements
                temp = S[Ptr1];
                S[Ptr1] = S[Ptr2];
                S[Ptr2] = temp;
            }
        } catch (Exception ex) {
            System.out.println("Exception at initialization() method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
    }

    // read the key from the file as a set of bytes
    public void readKey() {
        try {
            // read the key from the text file
            DataInputStream dataInputStream = getReadStream((strkeyFile));
            int keylength = dataInputStream.available();
            signedByteKey = new byte[keylength];
            for (int index = 0; index < keylength; index++) {
                signedByteKey[index] = dataInputStream.readByte();
            }
        } catch (EOFException ex) {
            System.out.println("EOFException at readKey() method " + ex.getMessage());
            ex.printStackTrace(ps);
        } catch (IOException ex) {
            System.out.println("IOException at readKey() method " + ex.getMessage());
            ex.printStackTrace(ps);
        } catch (Exception ex) {
            System.out.println("Exception at readKey() method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
    }

    // Generate the RC4 key vector
    public void GenerateRC4Key() {
        try {
            int Ptr1 = 0;
            int Ptr2 = 0;
            int t;
            int temp;
            RC4Key = new int[MessageBlockSize];
            // 2nd Permutation of S to generate the secret keys
            for (int index = 0; index < MessageBlockSize; index++) {
                Ptr1 = (Ptr1 + 1) % MessageBlockSize;
                Ptr2 = (Ptr2 + S[index]) % MessageBlockSize;
                // permutation elements
                temp = S[Ptr1];
                S[Ptr1] = S[Ptr2];
                S[Ptr2] = temp;
                ////
                t = (S[Ptr1] + S[Ptr2]) % MessageBlockSize;
                RC4Key[index] = S[t];
            }
        } catch (Exception ex) {
            System.out.println("Exception at GenerateRC4Key() method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
    }

    // read the message from the text file as  a set of bytes
    public void readMessage() {
        try {
            // read the message from the text file
            DataInputStream dataInputStream = getReadStream(strInputFile);
            MessageBytesNum = dataInputStream.available();
            Message = new byte[MessageBytesNum];
            byte signedByteMsg;
            for (int index = 0; index < MessageBytesNum; index++) {
                // Java reads the bytes in sign byte format
                signedByteMsg = dataInputStream.readByte();
                Message[index] = signedByteMsg;
            }
        } catch (EOFException ex) {
            System.err.println("EOFException at readMessage() method " + ex.getMessage());
            ex.printStackTrace(ps);
        } catch (IOException ex) {
            System.err.println("IOException at readMessage() method " + ex.getMessage());
            ex.printStackTrace(ps);
        } catch (Exception ex) {
            System.err.println("Exception at readMessage() method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
    }

    // Start encryption / decryption the blocks of the message  
    // Read the whole message , divide into blocks and 
    // encrypt/decrypt each block
    public void startCiphering() {
        try {
            // read the whole message
            readMessage();
            // read the input key
            readKey();
            // divide the message into blocks and encrypt and decrypt each block 
            // start and end of the message block
            int start = 0;
            int end = 0;
            int index = 0;
            boolean flag = true;
            int cipherMsgeIndex;
            MesssageBlock = new byte[MessageBlockSize];
            CipherMessage = new byte[Message.length];
            int count = 0;
            initialization();
            while (flag) {
                count++;
                // get block from the message
                end = start + MessageBlockSize;
                cipherMsgeIndex = start;
                if (end >= Message.length) {
                    end = (Message.length) - 1;
                    flag = false;
                }
                for (; start < end; start++) {
                    MesssageBlock[index] = Message[start];
                    index++;
                }
                if (!flag) {
                    for (; index < MessageBlockSize; index++) {
                        MesssageBlock[index] = (byte) 10;
                    }
                }
                // Generate RC4 key vector

                GenerateRC4Key();
                /// Encryption and Decryption of the message
                System.out.println("Encryption data block");
                // Encrypt block of message
                Encryption();
                System.out.println();
                System.out.println("Decryption data block");
                // Decrypt block of message
                Decryption();
                System.out.println();
                index = 0;
                // save the blocks of cipher message
                for (; cipherMsgeIndex < end; cipherMsgeIndex++) {
                    CipherMessage[cipherMsgeIndex] = CipherBlock[index];
                    //System.out.print((char) CipherMessage[cipherMsgeIndex]);
                    index++;
                }
                index = 0;
            }
            // ciphering all the blocks write the cipher data to file
            FileOutputStream fs = new FileOutputStream(strOutputFile);
            DataOutputStream ds = new DataOutputStream(fs);
            ds.flush();
            ds.write(CipherMessage);
        } catch (Exception ex) {
            System.out.println("Exception at startCiphering() method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
    }

    // Encrypts Message block 
    // Xor the plaintext message block with key
    public void Encryption() throws FileNotFoundException, IOException {
        CipherBlock = new byte[MesssageBlock.length];
        int intCipherByte;
        for (int index = 0; index < MesssageBlock.length; index++) {
            intCipherByte = ((int) MesssageBlock[index] ^ (int) RC4Key[index]);
            CipherBlock[index] = (byte) intCipherByte;
            char x = (char) CipherBlock[index];
            System.out.print(x);
        }
    }

    // Decrypts message block
    // Xor encrypt message block with the key
    public void Decryption() {

        try {
            int intplainText;
            plainText = new byte[MesssageBlock.length];
            for (int index = 0; index < MesssageBlock.length; index++) {
                intplainText = ((int) CipherBlock[index] ^ (int) RC4Key[index]);
                if ((intplainText != -246) && (intplainText != 10)) {
                    byte x = (byte) intplainText;
                    System.out.print((char) x);
                }
            }
        } catch (Exception ex) {
            System.out.println("Exception at Decryption() Method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
    }

    public DataInputStream getReadStream(String fileRelativepath) {
        FileInputStream fileInputStream;
        DataInputStream dataInputStream = null;
        try {
            fileInputStream = new FileInputStream(fileRelativepath);
            dataInputStream = new DataInputStream(fileInputStream);
        } catch (FileNotFoundException ex) {
            System.out.println("FileNotFoundException at getReadStream() method " + ex.getMessage());
            ex.printStackTrace(ps);
        }
        return dataInputStream;
    }

    public int getUnsigendByte(Byte signedByte) throws Exception {
        int unsignedByte = (signedByte & 0xFF);
        return unsignedByte;
    }

}
