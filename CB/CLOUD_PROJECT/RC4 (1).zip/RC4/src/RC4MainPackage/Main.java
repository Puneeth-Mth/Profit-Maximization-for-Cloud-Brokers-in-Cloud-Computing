package RC4MainPackage;

public class Main {    
    public static void main(String[] args) {
        // Start Ciphering the message
        RC4 objRC4;
        objRC4 = new RC4();
        objRC4.startCiphering();
    }// end main   
}// end class
